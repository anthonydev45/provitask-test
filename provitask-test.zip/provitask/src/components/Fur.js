import React from 'react'

function Fur() {
  return (
    <div>HERE FUNITURI</div>
  )
}

export default Fur
import React from 'react'

function Locations() {
  return (
    <>
    <style type="text/css">
    {`
    * {
      background-color: purple;
    }
    `}
  </style>
    <div className='prueba'>Locations</div>
    </>
  )
}

export default Locations